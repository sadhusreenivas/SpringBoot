INSERT INTO volume(length, width, height) VALUES
(12,15,20),
(16, 14, 18),
(11, 9, 17);