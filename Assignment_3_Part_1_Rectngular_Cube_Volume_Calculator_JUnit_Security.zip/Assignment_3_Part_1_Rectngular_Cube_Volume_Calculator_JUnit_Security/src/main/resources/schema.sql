CREATE TABLE volume(
id LONG PRIMARY KEY AUTO_INCREMENT, 
length int,
width int,
height int
);
