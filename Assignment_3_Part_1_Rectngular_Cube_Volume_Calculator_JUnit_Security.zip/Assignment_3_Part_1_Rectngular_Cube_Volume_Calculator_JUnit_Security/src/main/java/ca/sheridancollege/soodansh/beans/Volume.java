package ca.sheridancollege.soodansh.beans;

import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Volume {
    Long id;
	private int length;
	private int width;
	private int height;
	
}
