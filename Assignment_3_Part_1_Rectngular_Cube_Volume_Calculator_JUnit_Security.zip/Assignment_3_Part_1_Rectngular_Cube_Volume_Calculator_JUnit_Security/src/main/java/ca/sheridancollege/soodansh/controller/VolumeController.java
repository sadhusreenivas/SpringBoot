package ca.sheridancollege.soodansh.controller;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.soodansh.beans.Message;
import ca.sheridancollege.soodansh.beans.Volume;
import ca.sheridancollege.soodansh.database.DatabaseAccess;

@Controller
public class VolumeController {

	List<Volume> volumeList = new CopyOnWriteArrayList<Volume>();	
		@Autowired
		private DatabaseAccess da;
		
		@Autowired
		private Message message;
		
		@GetMapping("/")
		public String index() {
			return "index";
		}
		
		@GetMapping("/secure")
		public String index(Model model) {
			model.addAttribute("volume", new Volume());
			model.addAttribute("volumeList", da.getAllVolumes());
			System.out.println(message);
			return "secure/index";
		}
	
		@PostMapping("/insertVolume")
		public String insertVolume(Model model, @ModelAttribute Volume volume) {
		da.insertVolume(volume.getLength(), volume.getWidth(), volume.getHeight()); 
		model.addAttribute("volume", new Volume());
		return "index";	
		}
		
		@GetMapping("/login")
		public String login() {
			return "login";
		}

		@GetMapping("/permission-denied")
		public String permissionDenied() {
			return "/error/permission-denied";
		}
		
}
