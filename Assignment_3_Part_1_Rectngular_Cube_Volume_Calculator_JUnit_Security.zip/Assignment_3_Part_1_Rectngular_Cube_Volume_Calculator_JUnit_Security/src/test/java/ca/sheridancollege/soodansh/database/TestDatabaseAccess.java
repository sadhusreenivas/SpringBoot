package ca.sheridancollege.soodansh.database;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase
public class TestDatabaseAccess {
	@Autowired
	private DatabaseAccess da;

	@Test
	public void whenInsertVolume_getAllVolumes() { 
		
		// when
		da.insertVolume(10,15,20);
		// then (the actual test!)
		Assert.assertTrue(da.getAllVolumes().size() > 0);
	}
	
}
