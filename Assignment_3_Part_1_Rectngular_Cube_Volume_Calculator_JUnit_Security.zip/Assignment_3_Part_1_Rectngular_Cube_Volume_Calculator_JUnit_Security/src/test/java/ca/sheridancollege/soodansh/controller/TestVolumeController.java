package ca.sheridancollege.soodansh.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ca.sheridancollege.soodansh.beans.Volume;

public class TestVolumeController {


	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testLoadingIndex() throws Exception { 
		this.mockMvc.perform(get("/"))
		. andExpect(status(). isOk()) .andExpect(view().name("index"));

	}
	
	@Test
	public void testLoadingInsertVolume() throws Exception {
		this.mockMvc.perform(post("/insertVolume").flashAttr("Volume", new Volume())) . andExpect(status(). isOk())
		.andExpect(view().name("index"));
	}


}
