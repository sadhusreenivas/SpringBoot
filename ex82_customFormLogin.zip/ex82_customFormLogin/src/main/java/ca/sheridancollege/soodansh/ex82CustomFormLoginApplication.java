package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ex82CustomFormLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(ex82CustomFormLoginApplication.class, args);
	}

}
