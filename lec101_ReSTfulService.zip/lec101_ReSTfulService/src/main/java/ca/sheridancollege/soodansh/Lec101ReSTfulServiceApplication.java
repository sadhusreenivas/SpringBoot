package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lec101ReSTfulServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lec101ReSTfulServiceApplication.class, args);
	}

}
