package ca.sheridancollege.soodansh.database;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class TestDatabaseAccess {

	@Autowired
	private DatabaseAccess da;

	@Test
	public void whenInsertStudent_getStudents() { 
		
		// when
		da.insertStudent("Anshul");
		// then (the actual test!)
		Assert.assertTrue(da.getStudents().size() > 0);
	}

}
