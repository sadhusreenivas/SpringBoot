package ca.sheridancollege.soodansh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex72JdbcTemplateTestingAndJUnitApplicationTests {

	@Test
	void contextLoads() {
	}

}
