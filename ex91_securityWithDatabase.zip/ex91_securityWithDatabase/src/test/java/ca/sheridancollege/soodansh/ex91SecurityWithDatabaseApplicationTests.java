package ca.sheridancollege.soodansh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ex91SecurityWithDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
