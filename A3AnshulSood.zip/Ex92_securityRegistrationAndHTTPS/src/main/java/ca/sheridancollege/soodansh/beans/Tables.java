package ca.sheridancollege.soodansh.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Tables {

	 private int id;
	 private int tableNo;
	 
	 public Tables(int tableNo) {
		 this.tableNo=tableNo;
	 }
}
