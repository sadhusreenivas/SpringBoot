package ca.sheridancollege.soodansh.beans;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class Billing {

	private int id;
    private int tableNo;
    private String waiterName;
    private double total;
    List<OrderItem> orderItems;
    
	public Billing(int tableNo, String waiterName, double total, List<OrderItem> orderItems) {
		
		this.tableNo = tableNo;
		this.waiterName = waiterName;
		this.total = total;
		this.orderItems = orderItems;
	}
    
	
    
}
