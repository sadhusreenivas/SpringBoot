package ca.sheridancollege.soodansh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.soodansh.beans.Billing;
import ca.sheridancollege.soodansh.beans.MenuItem;
import ca.sheridancollege.soodansh.services.BillService;
import ca.sheridancollege.soodansh.services.MenuService;

@Controller
public class WaiterController {

	 @Autowired
	 private MenuService menuService;

    @Autowired
    private BillService billService;

    
    @PostMapping("/order")
    public String submitOrder(@RequestParam("menuItems") List<Integer> menuItemIds,
                              @RequestParam("tableNo") int tableNo,  
                              @RequestParam("waiterName") String waiterName, 
                              Model model) {
       List<MenuItem> menuItems = menuService.getMenuItemsByIds(menuItemIds);
       Billing bill = billService.generateBill(tableNo, menuItems, waiterName );
       
       billService.createBill(bill); // creates the bill
       
       model.addAttribute("bill", bill);
       System.out.println("Test 123");
       
       return "waiter/finalbill";
    }

    @GetMapping("/finalbill")
    public String showFinalBill() {
        return "waiter/finalbill";
    }
}