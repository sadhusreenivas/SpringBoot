package ca.sheridancollege.soodansh.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import ca.sheridancollege.soodansh.beans.Billing;
import ca.sheridancollege.soodansh.beans.MenuItem;
import ca.sheridancollege.soodansh.beans.OrderItem;

@Service
public class BillService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    
    public void createBill(Billing bill) {
        String sql = "INSERT INTO Billing (tableNo, waiterName, total) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, bill.getTableNo(), bill.getWaiterName(), bill.getTotal());
    }
    
    public List<Billing> getAllBills() {
        String sql = "SELECT * FROM Billing";
        List<Billing> bills = jdbcTemplate.query(sql, new BillingRowMapper());
        return bills;
    }
    
    @SuppressWarnings("deprecation")
	public List<Billing> getBillsByTableNo(int tableNo) {
        String sql = "SELECT * FROM billing WHERE tableNo = ?";
        return jdbcTemplate.query(sql, new Object[]{tableNo}, new BillingRowMapper());
    }

    public double calculateGrandTotal(List<Billing> bills) {
        double grandTotal = 0.0;
        for (Billing bill : bills) {
            grandTotal += bill.getTotal();
        }
        return grandTotal;
    }
    
    private static class BillingRowMapper implements RowMapper<Billing> {
        @Override
        public Billing mapRow(ResultSet rs, int rowNum) throws SQLException {
            Billing bill = new Billing();
            bill.setId(rs.getInt("id"));
            bill.setTableNo(rs.getInt("tableNo"));
            bill.setWaiterName(rs.getString("waiterName"));
            bill.setTotal(rs.getDouble("total"));
            return bill;
        }
    }
    
    public Billing generateBill(int tableNo, List<MenuItem> menuItems, String waiterName) {
        double totalAmount = 0;
        
        List<OrderItem> orderItems = new ArrayList<>();
        
        for (MenuItem menuItem : menuItems) {
            totalAmount += menuItem.getPrice();
            orderItems.add(new OrderItem(menuItem,menuItem.getQuantity()));
        }
        
        //System.out.println("Test 123");
        return new Billing(tableNo,waiterName,totalAmount, orderItems);
    }
    

}

