package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A3AnshulSoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(A3AnshulSoodApplication.class, args);
	}

}
