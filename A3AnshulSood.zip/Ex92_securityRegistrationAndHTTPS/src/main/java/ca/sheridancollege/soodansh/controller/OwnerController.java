package ca.sheridancollege.soodansh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.soodansh.beans.Billing;
import ca.sheridancollege.soodansh.services.BillService;

@Controller
public class OwnerController {

    @Autowired
    private BillService billService;

    @GetMapping("/table")
    public String showTableSelection() {
        return "table";
    }

    @GetMapping("/allBills")
    public String showAllBills(@RequestParam("tableNo") int tableNo,
                               Model model) {
      List<Billing> bills = billService.getBillsByTableNo(tableNo);
      System.out.println(bills);
      double grandTotal = billService.calculateGrandTotal(bills);
      model.addAttribute("bills", bills);
      model.addAttribute("grandTotal", grandTotal);
        return "owner/allBills";
    }
}