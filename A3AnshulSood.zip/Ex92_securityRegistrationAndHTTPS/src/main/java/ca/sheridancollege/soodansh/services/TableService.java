package ca.sheridancollege.soodansh.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import ca.sheridancollege.soodansh.beans.Tables;

@Service
public class TableService {

    private List<Tables> tables = new ArrayList<>();

    public TableService() {
        tables.add(new Tables(1));
        tables.add(new Tables(2));
        tables.add(new Tables(3));
        tables.add(new Tables(4));
        tables.add(new Tables(5));
    }

    public List<Tables> getAllTables() {
        return tables;
    }

    public Tables getTableByNumber(int tableNo) {
        for (Tables table : tables) {
            if (table.getTableNo() == tableNo) {
                return table;
            }
        }
        return null;
    }
}
