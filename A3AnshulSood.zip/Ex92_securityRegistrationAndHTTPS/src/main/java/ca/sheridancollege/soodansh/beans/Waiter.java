package ca.sheridancollege.soodansh.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Waiter {

	private int id;
    private String firstName;
    private String lastName;
    private int tableNo;

}
