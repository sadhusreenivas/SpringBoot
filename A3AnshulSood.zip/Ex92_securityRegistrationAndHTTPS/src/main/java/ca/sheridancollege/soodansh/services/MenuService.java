package ca.sheridancollege.soodansh.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import ca.sheridancollege.soodansh.beans.MenuItem;

@Service
public class MenuService {

    private List<MenuItem> menuItems = new ArrayList<>();

    public MenuService() {
        // Initialize menu items
        menuItems.add(new MenuItem(1, "Classic Cheeseburger", 8.99,0));
        menuItems.add(new MenuItem(2, "Margherita Pizza", 10.99,0));
        menuItems.add(new MenuItem(3, "Grilled Chicken Sandwich", 9.99,0));
        menuItems.add(new MenuItem(4, "Caesar Salad", 7.99,0));
        menuItems.add(new MenuItem(5, "Fish and Chips", 11.99,0));
        menuItems.add(new MenuItem(6, "Veggie Burger", 8.99,0));
        menuItems.add(new MenuItem(7, "Spaghetti Bolognese", 12.99,0));
        menuItems.add(new MenuItem(8, "Chicken Alfredo", 13.99,0));
        menuItems.add(new MenuItem(9, "Club Sandwich", 10.99,0));
        menuItems.add(new MenuItem(10, "Quesadilla", 9.99,0));
    }

    public List<MenuItem> getAllMenuItems() {
        return menuItems;
    }

    public List<MenuItem> getMenuItemsByIds(List<Integer> menuItemIds) {
        List<MenuItem> selectedMenuItems = new ArrayList<>();
        for (Integer id : menuItemIds) {
            for (MenuItem menuItem : menuItems) {
                if (menuItem.getId() == id) {
                    selectedMenuItems.add(menuItem);
                    break;
                }
            }
        }
        return selectedMenuItems;
    }
}
