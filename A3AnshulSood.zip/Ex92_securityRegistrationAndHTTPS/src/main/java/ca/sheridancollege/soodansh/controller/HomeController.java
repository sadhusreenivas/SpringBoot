package ca.sheridancollege.soodansh.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.soodansh.beans.Billing;
import ca.sheridancollege.soodansh.beans.MenuItem;
import ca.sheridancollege.soodansh.beans.Tables;
import ca.sheridancollege.soodansh.database.DatabaseAccess;
import ca.sheridancollege.soodansh.services.BillService;
import ca.sheridancollege.soodansh.services.MenuService;
import ca.sheridancollege.soodansh.services.TableService;

@Controller
public class HomeController {
	
	@Autowired
	@Lazy
	private DatabaseAccess da;
   
	@Autowired
	    private MenuService menuService;
	@Autowired
        private TableService tableService; 
	@Autowired
    private BillService billService;
	  
	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/waiter")
	public String secureIndex(Authentication authentication,Model model) {
		String email = authentication.getName();
		List<String> roles = new ArrayList<String>();
		
		for (GrantedAuthority ga: authentication.getAuthorities()) {
		roles.add(ga.getAuthority());
		}
		
		model.addAttribute("email", email); 
		model.addAttribute("roles", roles);
		
	    List<MenuItem> menuItems = menuService.getAllMenuItems();
        
        model.addAttribute("menuItems",menuItems);
		return "/waiter/menu";
	}
    
	@GetMapping("/owner")
	public String secure(Authentication authentication,Model model) {
		String email = authentication.getName();
		List<String> roles = new ArrayList<String>();
		
		for (GrantedAuthority ga: authentication.getAuthorities()) {
		roles.add(ga.getAuthority());
		}
		
		model.addAttribute("email", email); 
		model.addAttribute("roles", roles);
		
	    List<Tables> tables = tableService.getAllTables();
        model.addAttribute("tables",tables);
        
		return "/owner/table";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
   
	
	@GetMapping("/permission-denied")
	public String permissionDenied() {
		return "/error/permission-denied";
	}

	@GetMapping("/register") 
	public String getRegister () {
		return "register";
		}
	
	@PostMapping("/register")
	public String postRegister(@RequestParam String username, @RequestParam String password) {
    
		da.addUser(username, password);
		Long userId = da.findUserAccount(username).getUserId();
		da.addRole(userId, Long.valueOf(1));
		da.addRole(userId, Long.valueOf(2));
	return "redirect:/";
}
	
	
}
