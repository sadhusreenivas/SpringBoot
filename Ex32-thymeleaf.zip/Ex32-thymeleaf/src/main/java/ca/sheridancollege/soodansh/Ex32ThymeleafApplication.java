package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex32ThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex32ThymeleafApplication.class, args);
	}

}
