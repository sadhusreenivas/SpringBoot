package ca.sheridancollege.soodansh.controller;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.soodansh.beans.Appointment;
import ca.sheridancollege.soodansh.database.DatabaseAccess;

@Controller
public class AppointmentController {

	List<Appointment> appointmentList = new CopyOnWriteArrayList<Appointment>();
		
		@Autowired
		private DatabaseAccess da;
		
		@GetMapping("/")
		public String index(Model model) {
			model.addAttribute("appointment", new Appointment());
			model.addAttribute("appointmentList", da.getAllAppointments());	
			return "index";
		}
	
		@PostMapping("/insertAppointment")
		public String insertAppointment(Model model, @ModelAttribute Appointment appointment) {
		da.insertAppointment(appointment.getFirstName(), appointment.getEmail(), appointment.getAppointmentDate(),appointment.getAppointmentTime()); 
		model.addAttribute("appointment", new Appointment());
		return "index";	
		}
		
		
		@GetMapping("/deleteAppointment/{id}")
		public String deleteAppointment(Model model, @PathVariable Long id) { 
			
			da.deleteAppointment(id);
			
			model.addAttribute("appointment", new Appointment());
			model.addAttribute("appointmentList", da.getAllAppointments());
			return "index";
		}
		
		
		@GetMapping("/editAppointment/{id}")
		public String editAppointment(Model model, @PathVariable Long id) {
			Appointment appointment = da.getAppointmentById(id).get(0);
			model.addAttribute("appointment", appointment);
			
			da.deleteAppointment(id); 
			model.addAttribute("studentList", da.getAllAppointments());
			return "index";
		}
		
	
	
	

}
