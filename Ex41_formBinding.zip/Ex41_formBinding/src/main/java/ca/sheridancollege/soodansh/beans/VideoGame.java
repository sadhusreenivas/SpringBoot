package ca.sheridancollege.soodansh.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VideoGame {

	private Long id;
	private String title;
	private String publisher;
	private String platform;
	private double price;
	
	String[] platforms = {"PS4", "XBox", "TC", "PSP"};

}
