package ca.sheridancollege.soodansh.controller;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.soodansh.beans.VideoGame;

@Controller
public class GameController {
	
	private List<VideoGame> gameList = new CopyOnWriteArrayList<VideoGame>();
	
	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("videoGame", new VideoGame());
		model.addAttribute("gameList",gameList);
		
		return "index";
	}
	
	@PostMapping("/addGame")
    public String addGame(@ModelAttribute VideoGame videoGame, Model model ) {
    	
    	gameList.add(videoGame);
    	
    	model.addAttribute("videoGame", new VideoGame());
		model.addAttribute("gameList",gameList);
    	
    	return "index";
    }
	
}
