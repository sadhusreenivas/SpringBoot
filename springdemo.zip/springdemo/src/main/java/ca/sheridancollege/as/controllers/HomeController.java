package ca.sheridancollege.as.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller  // can handle http requests
public class HomeController {

	@GetMapping("/abc")  // localhost:8080/abc
	public String myName(){
		return "name"; // name.html - view resolver
	}
	
	@GetMapping("/")  // localhost:8080/
	public String load() {
		return "index"; // index.html
	}
	
	@GetMapping("/country")
	public String getCountry() {
		return "country"; // country.html
	}
	
	
	
}
