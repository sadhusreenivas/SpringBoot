package ca.sheridancollege.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class HomeController {
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/form")	
	public String form() {
		return "javaFun";
	}
	
	@PostMapping("/submitForm")
	public void submitForm(@RequestParam(value = "addtomailinglist", defaultValue = "false") boolean addToMailingList,
                           @RequestParam("name") String name,
                           @RequestParam("email") String email,
                           @RequestParam("javaisfun") String javaIsFun,
                           HttpServletResponse response) throws IOException {
		
		PrintWriter out = response.getWriter();
		
		if(addToMailingList && javaIsFun.equals("yes")) {
			out.println("<body bgcolor='orange'><div align='center'><br>");
			out.println("<h1> Thanks for filling out the form, "+name+"</h1><br>");
			out.println("<h2> Glad you're having fun!</h2><br>");
			out.println("<h3>We'll add your email: "+email+" to our list</h3>");
			out.println("</body></div>");
			
		}
		else { 
			out.println("<body bgcolor='yellow'><div align='center'><br>");
			out.println("<h1> Thanks for filling out the form, "+name+"</h1><br>");
			out.println("<h2> Hope its get better!</h2><br>");
			out.println("<h3>We won't add your email: "+email+" to our list</h3>");
			out.println("<body bgcolor='cyan'><div align='center'>");
		}
		
		
	}
	
}
