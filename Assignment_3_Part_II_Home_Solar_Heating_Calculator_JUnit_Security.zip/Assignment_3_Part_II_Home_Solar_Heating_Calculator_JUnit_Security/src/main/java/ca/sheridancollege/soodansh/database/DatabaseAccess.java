package ca.sheridancollege.soodansh.database;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.soodansh.beans.SolarHome;

@Repository
public class DatabaseAccess {
	
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	public List<SolarHome> getAllSolarHomes() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM solarhome";
		return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<SolarHome>(SolarHome.class));
		}
	
	public void insertSolarHome(String homeStyle, int homeSize, double sunlightIndex, String homeFacingCardinalDirection, String solarHeatingType) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource(); 
		String query="INSERT INTO solarhome(homeStyle,homeSize,sunlightIndex,homeFacingCardinalDirection,solarHeatingType) VALUES (:homeStyle,:homeSize,:sunlightIndex,:homeFacingCardinalDirection,:solarHeatingType)";
		
		namedParameters.addValue("homeStyle", homeStyle);
		namedParameters.addValue("homeSize", homeSize);
		namedParameters.addValue("sunlightIndex", sunlightIndex);
		namedParameters.addValue("homeFacingCardinalDirection", homeFacingCardinalDirection);
		namedParameters.addValue("solarHeatingType", solarHeatingType);
		
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
	    System.out.println("Inserted SolarHomes into database");
     }

}
