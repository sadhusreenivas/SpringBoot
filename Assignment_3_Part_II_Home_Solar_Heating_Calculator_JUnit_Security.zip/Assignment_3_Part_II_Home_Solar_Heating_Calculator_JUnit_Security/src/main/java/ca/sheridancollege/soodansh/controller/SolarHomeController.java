package ca.sheridancollege.soodansh.controller;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.soodansh.beans.Message;
import ca.sheridancollege.soodansh.beans.SolarHome;
import ca.sheridancollege.soodansh.database.DatabaseAccess;

@Controller
public class SolarHomeController {

	List<SolarHome> solarHomeList = new CopyOnWriteArrayList<SolarHome>();
		@Autowired
		private DatabaseAccess da;
		
		@Autowired
		private Message message;
		
		@GetMapping("/")
		public String index() {
			return "index";
		}
		
		@GetMapping("/secure")
		public String index(Model model) {
			model.addAttribute("solarHome", new SolarHome());
			model.addAttribute("solarHomeList", da.getAllSolarHomes());	
			System.out.println(message);
			return "secure/index";
		}
		
		@PostMapping("/insertSolarHome")
		public String insertSolarHome(Model model, @ModelAttribute SolarHome solarHome) {
		da.insertSolarHome(solarHome.getHomeStyle(), solarHome.getHomeSize(), solarHome.getSunlightIndex(),solarHome.getHomeFacingCardinalDirection(),solarHome.getSolarHeatingType()); 
		model.addAttribute("solarHome", new SolarHome());
		return "index";	
		}
		
		@GetMapping("/login")
		public String login() {
			return "login";
		}

		@GetMapping("/permission-denied")
		public String permissionDenied() {
			return "/error/permission-denied";
		}
		
}
