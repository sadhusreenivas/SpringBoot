CREATE TABLE solarhome(
id LONG PRIMARY KEY AUTO_INCREMENT, 
homeStyle VARCHAR(255),
homeSize int,
sunlightIndex float, 
homeFacingCardinalDirection VARCHAR(255),
solarHeatingType VARCHAR
);

