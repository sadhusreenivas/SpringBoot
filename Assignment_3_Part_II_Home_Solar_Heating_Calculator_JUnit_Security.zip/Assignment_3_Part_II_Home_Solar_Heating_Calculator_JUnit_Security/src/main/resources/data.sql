INSERT INTO solarhome(homeStyle,homeSize,sunlightIndex,homeFacingCardinalDirection,solarHeatingType) VALUES
('Victorian', 2400, 0.80, 'South-West','Solar Hot Water Induction'),
('Italian', 2100, 0.70, 'South-East','Solar Hot Water Induction'),
('Roman', 2000, 0.82, 'North-East','Solar Hot Water Induction'),
('FreeSpace', 2800, 0.75, 'East', 'Solar Hot Water Induction');


