package ca.sheridancollege.soodansh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.soodansh.beans.SolarHome;

@Controller
public class SolarHomeController {

	@GetMapping("/")
	public String index() {

		return "index"; // index.html
	}

	@PostMapping("/formPost")
	public String formPost(
			@RequestParam String homeStyle,
			@RequestParam int homeSize,
			@RequestParam double sunlightIndex,
			@RequestParam String homeFacingCardinalDirection,
			@RequestParam String solarHeatingType,
			Model model) {
		
		SolarHome solarHome = new SolarHome(homeStyle, homeSize, sunlightIndex, homeFacingCardinalDirection, solarHeatingType);
		System.out.println(solarHome); // display on console
		
		model.addAttribute("solarHome",solarHome); // to display details on working html
		
		return "working"; // working.html
	}
}
