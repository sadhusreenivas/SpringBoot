package ca.anshul_sood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnshulSoodMidtermApplicationTests {

	@Test
	void contextLoads() {
	}

}
