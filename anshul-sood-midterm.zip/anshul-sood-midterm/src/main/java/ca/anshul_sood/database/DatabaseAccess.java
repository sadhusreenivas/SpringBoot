package ca.anshul_sood.database;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.anshul_sood.beans.Users;



@Repository
public class DatabaseAccess {

	private NamedParameterJdbcTemplate jdbc;
	
	public DatabaseAccess(NamedParameterJdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	
	List<Users> userList = new ArrayList<>();
	public List<Users> getUsers(){
		
		String query = "select * from users";
		
		 userList = jdbc.query(query, 
						 new BeanPropertyRowMapper<Users>(Users.class));
		
		return userList;
	}
	
	public int registerUser(Users users) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query = "insert into users (name,password,phone) values (:name, :password,:phone)";
		
		np.addValue("name", users.getName());
		np.addValue("password", users.getPassword());
		np.addValue("phone", users.getPhone());
		
		return jdbc.update(query, np);
	}
	
	
	public boolean validate(Users users) {
	
		MapSqlParameterSource np = new MapSqlParameterSource();
		
		String query="select * from users where name=:name and password=:password";
		np.addValue("name", users.getName());
		np.addValue("password", users.getPassword());
 
		List<Users> lh = jdbc.query(query, np,
				new BeanPropertyRowMapper<Users>(Users.class));
		
		if(lh.isEmpty())
			return false;
		else
			return true;
	}
}
