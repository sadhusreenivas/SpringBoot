package ca.anshul_sood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnshulSoodMidtermApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnshulSoodMidtermApplication.class, args);
	}

}
