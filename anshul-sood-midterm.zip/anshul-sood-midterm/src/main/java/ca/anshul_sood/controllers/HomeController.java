package ca.anshul_sood.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ca.anshul_sood.beans.Users;
import ca.anshul_sood.database.DatabaseAccess;



@Controller
public class HomeController {
	
	@Autowired
	private DatabaseAccess da;
	
	@GetMapping("/")
	public String index(Model model) {	
		return "index";
	}
	
	
	@GetMapping("/register")
	public String register(Model model) {
		
		return "register";
	}
	
	@PostMapping("/welcome")
	public String welcome(Model model, @ModelAttribute Users users) {
		
		 boolean status = da.validate(users);
			
			if(status) {
				model.addAttribute("users",users);
				return "invalid.html";
				
			}
		
		model.addAttribute("users",users);
		
		List<Users> userList = da.getUsers();
		
		System.out.println(userList);
		model.addAttribute("userList",userList);
		
		return "welcome";
	}
	
	@PostMapping("/register")
	public String registerUser(@ModelAttribute Users users) {
		
		int value = da.registerUser(users);
		
		System.out.println("return value is " + value);
		System.out.println("Registered Successfully!");
		
		return "test/index";
	}
}
