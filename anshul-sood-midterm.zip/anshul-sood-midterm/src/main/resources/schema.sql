create table users(
 id LONG PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(50),
 password VARCHAR(50),
 phone VARCHAR(50)
 );