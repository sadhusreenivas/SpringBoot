insert into users (name,password,phone) 
values ('Bugs','Bunny','555-1212'),
       ('Daffy','Duck','123-4567')
       ;