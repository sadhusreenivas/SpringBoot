package ca.sheriadancollege.controllers;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheriadancollege.beans.Missions;
import ca.sheriadancollege.database.DatabaseAccess;


@Controller
public class HomeController {
	
	@Autowired
	private DatabaseAccess da;
	List<Missions> missionList = new CopyOnWriteArrayList<Missions>();
			
	@GetMapping("/")
	public String index(Model model) {
		missionList = da.getMissions();
		System.out.println(missionList);
		
		model.addAttribute("missionList", missionList);
		model.addAttribute("missions", new Missions());
		return "index";
	}
	
	@GetMapping("/create_mission")
	public String createMission(Model model) {
		
		model.addAttribute("missions", new Missions());
		model.addAttribute("missionList", missionList);
		
		return "create_mission";
	}
	
	@PostMapping("/add_mission")
	public String addMission(@ModelAttribute Missions missions) {
    
		int value = da.addMission(missions);
		if (value>0)
		System.out.println("mission inserted successfully");
		
		return "redirect:/";	
	}
	
	@PostMapping("/view_missions")
	public String viewMissions(Model model, @ModelAttribute Missions missions) {
		missionList = da.getMissionByAgent(missions.getAgent());
		
		model.addAttribute("missions", missions);
		model.addAttribute("missionList", missionList);
		
		return "view_missions";
	}
	
	@GetMapping("/delete_Mission/{id}")
	public String deleteMission(@PathVariable Long id) {
		
		int value = da.deleteMission(id);
		if (value>0)
			System.out.println("mission deleted successfully");
		
		return "redirect:/";
	}
	
	@GetMapping("/edit_Mission/{id}")
	public String editMission(@PathVariable Long id, Model model) {
		Missions missions = da.getMissionById(id);
		
		model.addAttribute("missions",missions);
		
		return "edit_mission";
	}
	
	@PostMapping("/update_Mission")
	public String updateMission(@ModelAttribute Missions missions) {
		/*
		System.out.println(missions.getAgent());
		System.out.println(missions.getTitle());
		System.out.println(missions.getGadget1());
		System.out.println(missions.getGadget2());
		System.out.println(missions.getId()); */
		
		int value = da.updateMission(missions);
		System.out.println(value);
		if (value>0)
			System.out.println("mission updated successfully");
		
		return "redirect:/";
	}
	
	
}
