package ca.sheriadancollege.database;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheriadancollege.beans.Missions;


@Repository
public class DatabaseAccess {
	
	@Autowired
	private NamedParameterJdbcTemplate jdbc;
	
	
	public List<Missions> getMissions() {
		    List<Missions> missionList = new ArrayList<Missions>();
			String query = "select * from missions";
			
			 missionList = jdbc.query(query, 
							 new BeanPropertyRowMapper<Missions>(Missions.class));
			
		return missionList;
	}
	
	
	public int addMission(Missions mission) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query = "Insert into missions (title,agent, gadget1, gadget2)"
				+ " values (:title,:agent,:gadget1,:gadget2)";
		
		np.addValue("title", mission.getTitle());
		np.addValue("agent", mission.getAgent());
		np.addValue("gadget1", mission.getGadget1());
		np.addValue("gadget2", mission.getGadget2());
		
		return jdbc.update(query, np);
	}
	
	public int deleteMission(Long id) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query = "delete from missions where id = :id";
		np.addValue("id", id);
		
		return jdbc.update(query, np);
	}
	
	public Missions getMissionById(Long id) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query="select * from missions where id=:id";
		np.addValue("id", id);
		
		List<Missions> lh = jdbc.query(query, np,
				new BeanPropertyRowMapper<Missions>(Missions.class));
		if(lh.isEmpty())
			return null;
		else
			return lh.get(0);
	}
	
	public List<Missions> getMissionByAgent(String agent) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query="select * from missions where agent=:agent";
		np.addValue("agent", agent);
		
		List<Missions> lh = jdbc.query(query, np,
				new BeanPropertyRowMapper<Missions>(Missions.class));
		
			return lh;
	}
	
	public int updateMission(Missions mission) {
		MapSqlParameterSource np = new MapSqlParameterSource();
		String query = "update missions set title=:title, agent=:agent, gadget1=:gadget1, gadget2=:gadget2 where id=:id";
		np.addValue("title", mission.getTitle());
		np.addValue("agent", mission.getAgent());
		np.addValue("gadget1",mission.getGadget1());
		np.addValue("gadget2",mission.getGadget2());
		np.addValue("id",mission.getId());
		return jdbc.update(query, np);
	}


}
