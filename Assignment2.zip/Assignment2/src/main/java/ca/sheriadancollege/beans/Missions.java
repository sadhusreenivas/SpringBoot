package ca.sheriadancollege.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Missions {
	private Long id;
	private String agent;
	private String title;
	private String gadget1;
	private String gadget2;

}
