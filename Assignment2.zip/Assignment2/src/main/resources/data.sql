insert into missions(agent,title,gadget1, gadget2)
values ('Johnny English','Rescue the Queen',
'Exploding Cigar','Voice controlled Rolls Royce'),
('Natasha Romanova','Kill Iron Man',
'Armored Suit','Indestructable Ploe'),
('Anshul Rocks','Save Earth',
'Armored Suit','Auto Wings'),
('Eleven','Kill Armagadon',
'Armored Suit','Mind Power');
