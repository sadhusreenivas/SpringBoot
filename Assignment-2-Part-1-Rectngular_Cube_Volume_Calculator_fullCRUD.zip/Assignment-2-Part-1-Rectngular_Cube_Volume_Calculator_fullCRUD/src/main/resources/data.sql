INSERT INTO volume(length, width, height) VALUES
(12,15,25),
(16, 14, 18),
(11, 9, 17);