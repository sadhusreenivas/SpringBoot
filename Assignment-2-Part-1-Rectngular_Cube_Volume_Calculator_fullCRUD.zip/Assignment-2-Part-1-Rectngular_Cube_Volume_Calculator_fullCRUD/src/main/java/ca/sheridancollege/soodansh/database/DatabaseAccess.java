package ca.sheridancollege.soodansh.database;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.soodansh.beans.Volume;

@Repository
public class DatabaseAccess {
	
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	public List<Volume> getAllVolumes() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM Volume";
		return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<Volume>(Volume.class));
		}
	
	
	
	public void insertVolume(int length, int width, int height) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource(); 
		String query="INSERT INTO Volume(length, width, height) VALUES (:length,:width,:height)";
		
		namedParameters.addValue("length", length);
		namedParameters.addValue("width", length);
		namedParameters.addValue("height", height);
		
		
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
	    System.out.println("Inserted volume object values into database");
}
	
	
	public void deleteVolume(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource(); 
		String query = "DELETE FROM volume WHERE id = :id";
		namedParameters.addValue("id", id);
		int rowsAffected = jdbc.update(query, namedParameters); 
		if (rowsAffected > 0)
		System.out.println("Deleted Volume ID " + id + " from database");
		
		}
	
	
	public List<Volume> getVolumeById(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM volume WHERE id = :id";
		namedParameters.addValue("id", id);
		return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<Volume>(Volume. class));
		}
	


}
