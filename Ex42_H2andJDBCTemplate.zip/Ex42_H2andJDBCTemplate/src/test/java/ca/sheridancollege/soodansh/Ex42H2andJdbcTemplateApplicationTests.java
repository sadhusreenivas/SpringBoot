package ca.sheridancollege.soodansh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex42H2andJdbcTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
