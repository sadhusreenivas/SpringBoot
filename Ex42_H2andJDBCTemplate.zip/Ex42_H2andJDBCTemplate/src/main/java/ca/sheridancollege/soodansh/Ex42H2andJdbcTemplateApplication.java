package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex42H2andJdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex42H2andJdbcTemplateApplication.class, args);
	}

}
