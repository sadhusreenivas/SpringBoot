INSERT INTO student(name) VALUES
('Sally'),
('Harminder'), 
('Sue'), 
('Jaspreet');
