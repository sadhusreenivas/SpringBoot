package ca.sheridancollege.soodansh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.soodansh.beans.Message;
import ca.sheridancollege.soodansh.beans.Volume;

@Controller
public class VolumeController {
	
	@Autowired
	private Message message;  // DI
	
    @GetMapping("/")
	public String index() {
    	System.out.println(message); // message.toString()
		return "index";
	}
	
    @PostMapping("/formPost")
    public String formPost(
    		@RequestParam int length,
    		@RequestParam int width,
    		@RequestParam int height,
    		Model model) {
    	
    	Volume volume = new Volume(length, width, height);
    	
    	int volumeOfTheCube = volume.getLength()*volume.getWidth()*volume.getHeight();
    	
    	model.addAttribute("volumeOfTheCube", volumeOfTheCube);
    	
    	return "result";
    }
	
}
