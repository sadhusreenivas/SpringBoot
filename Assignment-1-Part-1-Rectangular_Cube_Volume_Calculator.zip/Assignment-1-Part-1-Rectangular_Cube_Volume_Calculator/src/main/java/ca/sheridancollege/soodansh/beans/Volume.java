package ca.sheridancollege.soodansh.beans;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Volume {

	private int length;
	private int width;
	private int height;
	
}
