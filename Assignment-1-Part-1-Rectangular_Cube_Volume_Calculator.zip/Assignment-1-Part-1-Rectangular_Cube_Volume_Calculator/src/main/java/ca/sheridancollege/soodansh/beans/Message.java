package ca.sheridancollege.soodansh.beans;

import org.springframework.stereotype.Component;

@Component
public class Message {
	
	private final String NAME = "ANSHUL SOOD";
	private final int STUDENT_NUMBER = 991684420;
	
	@Override
	public String toString() {
		return "NAME = " + NAME + "\nSTUDENT_NUMBER = " + STUDENT_NUMBER;
	}

}
