package ca.sheridancollege.soodansh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Part1RectangularCubeVolumeCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Part1RectangularCubeVolumeCalculatorApplication.class, args);
	}

}
