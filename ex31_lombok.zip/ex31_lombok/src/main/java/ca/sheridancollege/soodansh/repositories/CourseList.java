package ca.sheridancollege.soodansh.repositories;

import java.util.List;

import ca.sheridancollege.soodansh.beans.Course;

public interface CourseList {

	public List<Course> getCourseList();
	
	public void setCourseList(List<Course> courseList);
	
	public void emptyList();

}
