package com.fdmgroup.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fdmgroup.employee.model.Employee;
import com.fdmgroup.employee.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	// show all employees and present menu - add / update / delete
	@GetMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("listEmployees", employeeService.getAllEmployees());
		return "index";

	}

	// creating a new employee
	@PostMapping("/createEmployee")
	public String createEmployee(@ModelAttribute("employee") Employee employee) {
		employeeService.createEmployee(employee);
		return "redirect:/";
	}

	// presenting employee form
	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "newEmployee";
	}

	// delete the employee by id
	// "http://localhost:8080/delete/{employee's id}"
	@GetMapping("/delete/{id}")
	public String deleteEmployeeById(@PathVariable Long id, Model model) {
		String str = employeeService.deleteEmployeeById(id);
        System.out.println(str);
		// after delete the employee data from database, redirect to "/"
		return "redirect:/";
	}

	// present update form
	// "http://localhost:8080/showFormForUpdate/{employee's id}"
	@GetMapping("/showFormForUpdate/{id}")
	public String showUpdateForm(@PathVariable Long id, Model model) {

		Employee employee = employeeService.getEmployeeById(id);

		// We set employee data as "employee"
		model.addAttribute("employee", employee);

		// shows the update_employee.html template:
		return "updateEmployee";
	}
	
	// presenting search employee form
		@GetMapping("/showSearchEmployeeForm")
		public String showSearchEmployeeForm(Model model) {
			Employee employee = new Employee();
			model.addAttribute("employee", employee);
			return "searchEmployee";
		}
	
	// search employee by firstName and lastName
	@PostMapping("/searchByName")
    public String SearchEmployeebyName(@RequestParam String firstName, @RequestParam String lastName,@RequestParam Long id) {
         String str= employeeService.getEmployeeByName(firstName, lastName, id);
         System.out.println(str);
         return "redirect:/";
    }
	
	

}
