package com.fdmgroup.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdmgroup.employee.model.Employee;
import com.fdmgroup.employee.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepo;

	// view all employees
	public List<Employee> getAllEmployees() {
		return employeeRepo.findAll();
	}

	// create employees
	public void createEmployee(Employee employee) {
		employeeRepo.save(employee);
	}

	// delete employee by id
	public String deleteEmployeeById(Long id) {
		Employee employee = employeeRepo.getById(id);
		if (employee == null) {
			throw new RuntimeException("Employee not found");
		}
		employeeRepo.deleteById(id);
		return "Deleted: " + employee.getFirstName() + "  " + employee.getLastName();
	}

//	get employee by id
	public Employee getEmployeeById(Long id) {
		// find an employee by id
		Employee emp = employeeRepo.getById(id);

		// if there is not an employee who has the id, throw the error.
		if (emp == null) {
			throw new RuntimeException("Employee not found");
		}
		return emp;
	}

	// search employee by first name and last name
	public String getEmployeeByName(String firstName, String lastName,Long id) {
		
		Employee employee = employeeRepo.getById(id);
		
		if(employee.getFirstName().equalsIgnoreCase(firstName) && employee.getLastName().equalsIgnoreCase(lastName))
		{
		return "Employee Found: " + employee.getFirstName()+"  "+employee.getLastName()+"  "+employee.getAddress()+"  "+employee.getHireDate();
		}
		else throw new RuntimeException("Employee not found"); 
			
	}

}
