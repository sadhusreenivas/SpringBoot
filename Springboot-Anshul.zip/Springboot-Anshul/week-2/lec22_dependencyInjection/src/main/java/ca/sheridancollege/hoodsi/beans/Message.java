package ca.sheridancollege.hoodsi.beans;

import org.springframework.stereotype.Component;

@Component // note the import: this is a Spring annotation and tell Spring to instantiate one of these and put it on ice in an Inversion of Control container
public class Message {

	private String sayThis = "Woah! Spring is powerful stuff!!";

	@Override
	public String toString() {
		return "Message [sayThis=" + sayThis + "]";
	}
	
	
	
}
