package ca.sheridancollege.hoodsi.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Student {

	private Long id;
	private String name;
	
}
