package ca.sheridancollege.hoodsi.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ca.sheridancollege.hoodsi.beans.Student;
import ca.sheridancollege.hoodsi.database.DatabaseAccess;

@Controller
public class StudentController {

	@Autowired
	private DatabaseAccess da;
	
	@GetMapping("/")
	public String index(Model model) {
		da.insertStudent();
		model.addAttribute("student", new Student());
		return "index";
	}
}
